<?php

use Phalcon\Mvc\Collection;

Class Movies extends Collection{
    
}